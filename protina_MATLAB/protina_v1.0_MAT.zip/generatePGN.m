function pgn = generatePGN(GList,tftg,ppi,ppi_thre,tftg_thre,ptf_thre)

%-------------------------------------------------------------------------
%DESCRIPTION:
%           This function constructs the protein-gene network (PGN) by 
%           combining TF-gene and protein-protein interaction networks.
%
%INPUT ARGUMENTS:
%GList      	The n x 1 vector of genes in the same order of the genes in
%               log2FC data. The length (n) of `GList` should be the same 
%               as the number of rows in log2FC data.
%tftg           The matrix of TF-gene interactions. The first column is the
%               list of TFs, and the second column is the list of genes 
%               regulated by the corresponding TFs. The third column is 
%               optional, and if present, the column should contain the 
%               (confidence) score for each interaction.
%ppi            The matrix of protein-protein interactions. Each row of the
%               first two columns give the protein pairs with interactions.
%               The third column is optional, and if present, the column 
%               should contain the (confidence) score for each interaction.
%tftg_thre      A threshold for TF-gene interactions. This variable is used
%               only when the confidence score of TF-gene interactions are 
%               given in the matrix `tftg`. Any TF-gene interactions with 
%               confidence scores lower than the threshold will be excluded.
%ptf_thre       A threshold for protein-TF interaction. This variable is 
%               used only when the confidence score of protein-TF 
%               interactions are given in the matrix `ppi`.  Any protein-TF
%               interactions with the scores lower than the threshold will 
%               be excluded.
%ppi_thre       A threshold for protein-protein interaction. This variable 
%               is used only when the confidence score of protein-protein 
%               interactions are given in the matrix `ppi`.  Any 
%               protein-protein interactions with the scores lower than the
%               threshold will be excluded.
%
%OUTPUT ARGUMENTS:
%pgn            The n*n adjacency matrix of PGN. The elements of the matrix
%               are either 0 or 1. The rows and columns correspond to 
%               proteins and genes, respectively, which follow the order 
%               given in GList. If the (i, j)-th element of the matrix is 1,
%               then there exists a regulatory edge from protein i to gene 
%               j in the PGN, i.e. protein i is regulating the expression 
%               of gene j.
%--------------------------------------------------------------------------

    if nargin<4 || isempty(ppi_thre)
        ppi_thre = 0;
    end
    
    if nargin<5 || isempty(tftg_thre)
        tftg_thre = 0;
    end
    
    if nargin<6 || isempty(ptf_thre)
        ptf_thre = 0;
    end
    
    n = length(GList);
    
    %%%%%%%%%%%%%%%%%%%%%%%% GRN CONSTRUCTION %%%%%%%%%%%%%%%%%%%%%%%%
    %%% Check whether tftg has 3rd column (= score)
    if size(tftg,2)<3
        tftg = [tftg,num2cell(ones(size(tftg,1),1))];
        tftg_thre = 0;
    end
    
    %%%% Trim TF-gene interactions (high score & existing in GList)
    tftg = tftg(cell2mat(tftg(:,3)) > tftg_thre,:);
    mem1 = ismember(upper(tftg(:,1)),upper(GList));
    mem2 = ismember(upper(tftg(:,2)),upper(GList));
    tftg = tftg(mem1 & mem2,:);

    %%%% GRN construction
    grn = zeros(n);
    tf = unique(tftg(:,1));

    for j=1:length(tf)
        [~,tgi]=ismember(upper(tftg(strcmpi(tf(j),tftg(:,1)),2)),upper(GList));
        grn(strcmpi(tf(j),GList),tgi) = 1;
    end

    grn = sparse(grn);

    %%%% summary %%%%
    tfn = length(tf);
    dgn = nnz(sum(grn~=0,1));
    edgen = nnz(grn);
    fprintf('TF-Gene network (%d TFs, %d genes, %d interactions) has been generated.\n',tfn,dgn,edgen);
    
    %%%%%%%%%%%%%%%%%%% PPI NETWORK CONSTRUCTION %%%%%%%%%%%%%%%%%%%%
    %%% Check whether tftg has 3rd column (= score)
    if size(ppi,2)<3
       ppi = [ppi,num2cell(ones(size(ppi,1),1))];
       ppi_thre = 0;
    end

    %%%% Trim PPIs (high score & existing in GList)
    mem1 = ismember(upper(ppi(:,1)),upper(GList));
    mem2 = ismember(upper(ppi(:,2)),upper(GList));
    ppi = ppi(mem1 & mem2,:);

    % index of ppi
    [~,ic1] = ismember(upper(ppi(:,1)),upper(GList));
    [~,ic2] = ismember(upper(ppi(:,2)),upper(GList));
    ppi_idx = [ic1,ic2,cell2mat(ppi(:,3:end))];

    % Remove duplicated interactions with lower scores
    ppi_idx(:,1:2) = sort(ppi_idx(:,1:2),2);
    ppi_idx = flipud(sortrows(ppi_idx));
    [~,uni] = unique(ppi_idx(:,1:2),'rows','stable');
    ppi_idx = flipud(ppi_idx(uni,:));

    % Remove self-loops
    selfloop = ppi_idx(:,1)-ppi_idx(:,2)==0;
    ppi_idx(selfloop,:) = [];


    %%%% Prot1 - TF network %%%%
    tf_idx = find(sum(grn~=0,2));
    e1 = find(ismember(ppi_idx(:,1),tf_idx) | ismember(ppi_idx(:,2),tf_idx));
    ppi_ly1 = ppi_idx(e1,:);
    proti1 = setdiff(unique(ppi_ly1(:,1:2)),tf_idx);

    % set the order (prot1-TF)
    x = find(ismember(ppi_ly1(:,1),tf_idx));
    ppi_ly1(x,[1,2]) = ppi_ly1(x,[2,1]);

    % If there is a TF1-TF2 interaction, copy as TF2-TF1 as well.
    copyi = ismember(ppi_ly1(:,1),tf_idx) & ismember(ppi_ly1(:,2),tf_idx);
    ppi_ly1 = [ppi_ly1; ppi_ly1(copyi,[2,1,3:end])];

    ppn1 = zeros(n);
    tfi2 = unique(ppi_ly1(:,2));
    for j=1:length(tfi2)
        ind = find(ppi_ly1(:,2)==tfi2(j));
        ppn1(ppi_ly1(ind,1),tfi2(j)) = ppi_ly1(ind,3);
    end
    
    ppn1(ppn1<ptf_thre)=0;
    ppn1 = sparse(ppn1);

    %%%% summary %%%%
    %prot1n = nnz(sum(ppn1~=0,2));
    %tfn = length(tfi2);
    %edgen = nnz(ppn1);
    %fprintf('Protein-TF network (%d proteins, %d TFs, %d interactions) has been generated.\n',prot1n,tfn,edgen);
    

    %%%% Prot2 - Prot1 network %%%%
    e2 = find(ismember(ppi_idx(:,1),proti1) | ismember(ppi_idx(:,2),proti1));
    e2 = setdiff(e2,e1);
    ppi_ly2 = ppi_idx(e2,:);

    % set the order (prot2-prot1)
    y = find(ismember(ppi_ly2(:,1),proti1));
    ppi_ly2(y,[1,2]) = ppi_ly2(y,[2,1]);

    % If there is Prot1a-prot1b interactions, copy as Prot1b-Prot1a as well.
    copyi = ismember(ppi_ly2(:,1),proti1) & ismember(ppi_ly2(:,2),proti1);
    ppi_ly2 = [ppi_ly2; ppi_ly2(copyi,[2,1,3])];

    ppn2 = zeros(n);
    proti1b = unique(ppi_ly2(:,2));
    for j=1:length(proti1b)
        ind = find(ppi_ly2(:,2)==proti1b(j));
        ppn2(ppi_ly2(ind,1),proti1b(j)) = ppi_ly2(ind,3);
    end
    
    ppn2(ppn2<ppi_thre)=0;
    ppn2 = sparse(ppn2);

    %%%% summary %%%%
    %prot2n = nnz(sum(ppn2~=0,2));
    %prot1n = nnz(sum(ppn2~=0,1));
    %edgen = nnz(ppn2);
    %fprintf('Protein-Protein network (%d upstream proteins, %d proteins, %d interactions) has been generated.\n',prot2n,prot1n,edgen);

    %%
    %%%%%%%%%%%%%%%%%%% PROTEIN-GENE NETWORK CONSTRUCTION %%%%%%%%%%%%%%%%%%%%
    pgn = (ppn2+eye(n))*ppn1;

    prot2n = nnz(sum(pgn~=0,2));
    prot1n = nnz(sum(pgn~=0,1));
    edgen = nnz(pgn);
    fprintf('Protein-Protein network (%d upstream proteins, %d TFs, %d interactions) has been generated.\n',prot2n,prot1n,edgen);



    pgn = (pgn + eye(n))*grn;
    pgn(find(eye(n)))=0;
    %%%% summary %%%%
    protn = nnz(sum(pgn~=0,2));
    dgn = nnz(sum(pgn~=0,1));
    edgen = nnz(pgn);
    fprintf('Protein-Gene network (%d proteins and TFs, %d downstream genes, %d interactions) has been generated.\n',protn,dgn,edgen);

    pgn(find(pgn~=0))=1;
    pgn = sparse(pgn);  
    
    fprintf('PGN is returned.\n');
end