function [Pscore,A] = protina(lfc, slope, pgn, grplist, kfold, par, numCores)

%--------------------------------------------------------------------------
%DESCRIPTION:
%           The main function for ProTINA for generating the protein scores 
%           for each drug treatment.
%
%INPUT ARGUMENTS:
%lfc             The matrix of log2FC data. Each row represents a gene and 
%                each column represents a sample.
%slope           The slope matrix from log2FC data. This matrix can be 
%                obtained using the function generateSlope(). If the data 
%                are not time-series, set slope to an empty matrix (i.e. 
%                slope=[]).
%pgn             The n*n adjacency matrix of the protein-gene regulation 
%                network, where n is the number of genes in GList. This 
%                matrix can be created using the function generatePGN().
%grplist         The group index for protein scoring. This vector defines 
%                the samples for which the protein scores are computed. The
%                length of this vector should be the same as the number of 
%                samples in the log2FC matrix. A single (aggregate) protein
%                score is generated for samples with the same index. The 
%                group indices should be a consecutive integer starting 
%                from 1 to the number of groups.
%kfold           The number of folds used in the k-fold cross validation.
%par             A Boolean variable TURE or FALSE indicating whether to use
%                parallel computing. The default is FALSE (no parallel 
%                computation).
%numCores        The number of CPU cores to be used for parallel computing.
%                This parameter is considered only if par is TRUE. The 
%                default is 4.
%
%OUTPUT ARGUMENTS:
%Pscore          The matrix of protein scores. Each row corresponds to a 
%                gene following the same order as the one in the log2FC 
%                data, while each column corresponds to a group of samples 
%                as defined in the grplist.
% A              The n*n matrix of edge weights of the PGN. The (i,j)-th 
%                element of the matrix corresponds to the weight of the
%                regulatory edge from protein j to gene i in the PGN, i.e. 
%                the regulation of the expression of gene i by protein j. 
%                The rows and columns of the matrix correspond to genes and
%                proteins in the PGN.
%--------------------------------------------------------------------------

if nargin<5 || isempty(kfold)
    kfold = 10;
end

if nargin < 6 || isempty(par)
    par = false;
end

if nargin < 7 || isempty(numCores)
    numCores = 4;
end

[n,m] = size(lfc);
f_lfc = sqrt(sum(lfc.^2,2))*sqrt(m);

if ~isempty(slope) 
    ms = size(slope,2);
    f_slope = sqrt(sum(slope.^2,2))*sqrt(ms);
    rho = f_lfc./f_slope;
    rho(rho==Inf) = 0;
end
dg = find(sum(pgn,1));

%% DeltaNeTS-ridge regression
fprintf('ProTINA is running...\n');

Ac=zeros(length(dg),n);
res = zeros(length(dg),m+ms);

opts = [];
opts.intr = 0;
opts.alpha = 0.0;

if par
    poolobj = gcp('nocreate');
    delete(poolobj);
    parpool('local',numCores)
      fprintf('Inferring weights of Protein-gene Network:\n');
      fprintf(['\n' repmat('.',1,length(dg)) '\n\n']);
    parfor j=1:length(dg)
       fprintf('\b|\n');
       ppar = find(pgn(:,dg(j))); 

       if ~isempty(slope)
           X = [lfc(ppar,:),rho(dg(j))*slope(ppar,:)];
           y = [lfc(dg(j),:),rho(dg(j))*slope(dg(j),:)];
       else
           X = lfc(ppar,:);
           y = lfc(dg(j),:);
       end

       Xin = [X',[eye(m);zeros(ms,m)]];
       result = cvglmnet(Xin,y',[],opts,[],kfold);
       lambda_opt = find(result.lambda==result.lambda_min);
       beta = result.glmnet_fit.beta(:,lambda_opt);
       Aj = zeros(n,1);
       Aj(ppar) = beta(1:end-m)';
       Ac(j,:) = Aj';
       r = (y-Aj(ppar)'*X);
       res(j,:) = r;
    end
    poolobj = gcp('nocreate');
    delete(poolobj)
else
       fprintf('Inferring weights of Protein-gene Network:\n');
       fprintf(['\n' repmat('.',1,length(dg)) '\n\n']);
    for j=1:length(dg)
        fprintf('\b|\n');
       ppar = find(pgn(:,dg(j))); 

       if ~isempty(slope)
           X = [lfc(ppar,:),rho(dg(j))*slope(ppar,:)];
           y = [lfc(dg(j),:),rho(dg(j))*slope(dg(j),:)];
       else
           X = lfc(ppar,:);
           y = lfc(dg(j),:);
       end

       Xin = [X',[eye(m);zeros(ms,m)]];
       result = cvglmnet(Xin,y',[],opts,[],kfold);
       lambda_opt = find(result.lambda==result.lambda_min);
       beta = result.glmnet_fit.beta(:,lambda_opt);
       Aj = zeros(n,1);
       Aj(ppar) = beta(1:end-m)';
       Ac(j,:) = Aj';
       
       r = (y-Aj(ppar)'*X);
       res(j,:) = r;
    end
end

%% Z-test

if size(grplist,1)>1
    grplist = grplist';
end
ugrplist = unique(grplist);
muni = length(ugrplist);

fprintf('Calculating z-scores for each edge...\n')

pval = ones(length(dg),muni);
z = zeros(length(dg),muni);

for j = 1:length(dg)
    r = res(j,:);
    for gri = 1:muni
        si = find(grplist==gri);
        mr = length(r);
        [~,p,~,zval] = ztest(r(si),0,sqrt(sum(r(setdiff(1:mr,si)).^2,2)/(mr-1-length(si))),'Tail','right');
        pval(j,gri) = p;
        z(j,gri) = zval;
    end
end

%% Combine Z-scores
fprintf('Combining z-scores for proteins...\n')

% normalized A coefficients are used as weights
Aw  = Ac./repmat(max(abs(Ac),[],2),[1,n]);
 
proti = find(sum(pgn(1:n,1:n),2));
zp = [];

% weighted z-score mean
for j=1:length(proti)
   tgi = find(pgn(proti(j),dg)); 
   w = Aw(tgi,proti(j));
   zp = [zp;(sum(z(tgi,:).*repmat(w,[1,size(z,2)]),1))/sqrt(sum(w.^2))];
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Pscore = zeros(n,muni);
Pscore(proti,:) = zp;

% scaling  A back to n*n matrix 
A = sparse(zeros(n));
A(dg,:) = Ac; 
fprintf('Pscore and A matrix are returned.\n')
end