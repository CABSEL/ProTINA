%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% An example script to run ProTINA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Preparation:
% set working directory and the paths of data and files accordingly
% cd('current_working_folder')
filepath = '.\';% filepath = 'set the current file path', note: '\'for window and '/' for Mac and Linux in defining a path;
datapath = strcat(filepath,'example_data\');

% import input data
lfc = dlmread(strcat(datapath,'lfc_mouse-pancreas-beta_13010genesX87samples.txt'),'\t');

tobject = readtable(strcat(datapath,'table_of_samples.txt'),'delimiter','\t');
grplist = tobject.group;
tp = tobject.time;
GList = readtable(strcat(datapath,'list_of_genes.txt'),'ReadVariableNames',false);
GList = GList.Var1;

% import TF-gene and protein-protein interactions data
tftg = readtable(strcat(datapath,'edges-TFTG_mouse_pancreas_fromCellNet.txt'),'delimiter','\t');
tftg = table2cell(tftg);
ppi = readtable(strcat(datapath,'edges_ppi_fromSTRING_short.txt'),'delimiter','\t');
ppi = table2cell(ppi);


%%% Protein-Gene Network Construction:

% calculate slopes of log2FC for each time point
slope = generateSlope(lfc,tp,grplist);

% generate protein-gene network (PGN)
ppi_thre = 500;
tftg_thre = 0;
ptf_thre = 0;

pgn = generatePGN(GList,tftg,ppi,ppi_thre,tftg_thre,ptf_thre);

%% ProTINA implementation with parallel computing 
% To run ProTINA, glmnet package is required. Plsease set glmnet path
% accordingly.
glmnetpath = strcat(filepath,'glmnet_matlab\glmnet_matlab\');
addpath(glmnetpath)

kfold = 10;
par = 0;
numCores = 2;
[Pscore,A] = protina(lfc,slope,pgn,grplist,kfold,par,numCores);
