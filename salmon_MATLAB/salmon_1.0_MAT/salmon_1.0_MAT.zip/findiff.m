function dfdt=findiff(tpoints,f,tsi)

%-------------------------------------------------------------------------
%DESCRIPTION:
%           This function implements a 2nd order accurate finite difference
%           for calculating slopes (time-derivatives) of the log2FC data 
%           using three time points. The function is used in generateSlope().
%INPUT ARGUMENTS:
%tpoints      A vector of three time points in increasing order. 
%             e.g. tpoints=[0 3 7];
%f            A submatrix of log2FC matrix log2(FC), whose columns 
%             correspond to the time points in tpoints.
%tsi          The index of the current time point (tsi=1 for the initial 
%             time point, tsi=2 for a middle time point, and tsi=3 for the
%             last time point among the time points in an experiment).
% 
%OUTPUT ARGUMENTS:
%df/dt        The 2nd order accuracy finite difference of log2FCs at a
%             current time point.
%-------------------------------------------------------------------------
%%
tdiff=tpoints-tpoints(tsi);

deltsind=find(tdiff>0,1,'first');
signdelts=1;
if isempty(deltsind)
    deltsind=find(tdiff<0,1,'last');
    signdelts=-1;
end
delt=tdiff/abs(tdiff(deltsind));
% delt([tsi,deltsind])=[];
Parind=1:1:length(tpoints);
Parind([tsi,deltsind])=[];
numPar=length(Parind);

xmat=[];
ymat=[];
for j=1:1:numPar
    xmat=[xmat;(delt(Parind).^(j+1))];
    ymat=[ymat;(signdelts)^(j+1)];
end
sol=xmat\-ymat;

dfdt=(-(1+sum(sol))*f(:,tsi) + f(:,deltsind) + f(:,Parind)*sol)/((signdelts + delt(Parind)*sol)*abs(tdiff(deltsind)));
